package com.aikyn.security.user;

public enum Role {
    USER

}
